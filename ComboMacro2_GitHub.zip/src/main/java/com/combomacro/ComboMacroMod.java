package com.combomacro;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class ComboMacroMod implements ClientModInitializer {

    // ─── SLOTLAR (0-index: slot1=0, slot9=8) ────────────────────────────────
    private static final int SLOT_ANCHOR   = 5; // Slot 6
    private static final int SLOT_GLOW     = 7; // Slot 8
    private static final int SLOT_PATLAT   = 8; // Slot 9 (dolu anchor - patlat)
    private static final int SLOT_OBSIDYEN = 3; // Slot 4
    private static final int SLOT_KRISTAL  = 1; // Slot 2

    private static final int KRISTAL_SAYISI = 5;

    // Ultra hızlı (ms)
    private static final int MIN_MS = 1;
    private static final int MAX_MS = 3;
    // ────────────────────────────────────────────────────────────────────────

    private boolean macroEnabled = false;
    private KeyBinding toggleKey;
    private boolean lastKeyState = false;

    // ADIMLAR:
    // 0 = Slot 6 seç (anchor)
    // 1 = Sağ tık (anchor koy)
    // 2 = Slot 8 seç (glowstone)
    // 3 = Sağ tık (glowstone koy - anchor doldur)
    // 4 = Slot 9 seç (dolu anchor)
    // 5 = Sağ tık (anchor patlat)
    // 6 = Slot 4 seç (obsidyen)
    // 7 = Sağ tık (obsidyen koy)
    // 8 = Slot 2 seç (kristal)
    // 9 = Kristal koy + patlat döngüsü (5 kez)

    private int step = 0;
    private int kristalCount = 0;
    private long nextAction = 0L;
    private final Random random = new Random();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.combomacro.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_6,
                "Combo Macro"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::renderHud);

        System.out.println("[ComboMacro] Yuklendi! 6 tusu ile ac/kapat.");
    }

    private void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;

        boolean keyDown = toggleKey.isPressed();
        if (keyDown && !lastKeyState) {
            macroEnabled = !macroEnabled;
            if (macroEnabled) {
                step = 0;
                kristalCount = 0;
                nextAction = System.currentTimeMillis();
                msg(client, "§a§lCOMBO MACRO §fACILDI");
            } else {
                msg(client, "§c§lCOMBO MACRO §fKAPANDI");
            }
        }
        lastKeyState = keyDown;

        if (!macroEnabled) return;
        if (System.currentTimeMillis() < nextAction) return;

        runStep(client);
    }

    private void runStep(MinecraftClient client) {
        switch (step) {

            // ── ANCHOR KOY ──────────────────────────────────────────────────
            case 0 -> { client.player.getInventory().selectedSlot = SLOT_ANCHOR;  step = 1;  delay(); }
            case 1 -> { sagTik(client);  step = 2;  delay(); } // anchor koy

            // ── GLOWSTONE (anchor doldur) ────────────────────────────────────
            case 2 -> { client.player.getInventory().selectedSlot = SLOT_GLOW;    step = 3;  delay(); }
            case 3 -> { sagTik(client);  step = 4;  delay(); } // glowstone koy

            // ── ANCHOR PATLAT ────────────────────────────────────────────────
            case 4 -> { client.player.getInventory().selectedSlot = SLOT_PATLAT;  step = 5;  delay(); }
            case 5 -> { sagTik(client);  step = 6;  delay(); } // anchor patlat (sağ tık)

            // ── OBSİDYEN KOY ────────────────────────────────────────────────
            case 6 -> { client.player.getInventory().selectedSlot = SLOT_OBSIDYEN; step = 7; delay(); }
            case 7 -> { sagTik(client);  step = 8;  delay(); } // obsidyen koy

            // ── KRİSTAL SEÇ ─────────────────────────────────────────────────
            case 8 -> {
                client.player.getInventory().selectedSlot = SLOT_KRISTAL;
                kristalCount = 0;
                step = 9;
                delay();
            }

            // ── KRİSTAL KOY + PATLAT × 5 ────────────────────────────────────
            case 9 -> {
                sagTik(client); // kristal koy
                step = 10;
                delay();
            }
            case 10 -> {
                solTik(client); // kristal patlat
                kristalCount++;
                if (kristalCount >= KRISTAL_SAYISI) {
                    step = 0; // başa dön
                } else {
                    step = 9; // tekrar kristal koy
                }
                delay();
            }
        }
    }

    private void sagTik(MinecraftClient client) {
        Vec3d eye  = client.player.getEyePos();
        Vec3d look = client.player.getRotationVec(1.0f);

        HitResult hit = client.world.raycast(new RaycastContext(
                eye,
                eye.add(look.multiply(4.5)),
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                client.player
        ));

        if (hit.getType() == HitResult.Type.BLOCK) {
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, (BlockHitResult) hit);
        } else {
            client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
        }
    }

    private void solTik(MinecraftClient client) {
        Vec3d eye  = client.player.getEyePos();
        Vec3d look = client.player.getRotationVec(1.0f);

        HitResult hit = client.world.raycast(new RaycastContext(
                eye,
                eye.add(look.multiply(4.5)),
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                client.player
        ));

        if (hit.getType() == HitResult.Type.BLOCK) {
            client.interactionManager.attackBlock(
                    ((BlockHitResult) hit).getBlockPos(),
                    ((BlockHitResult) hit).getSide()
            );
        } else {
            client.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void renderHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tc) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        TextRenderer font = client.textRenderer;
        int sw = client.getWindow().getScaledWidth();

        int pw = 175, ph = 75;
        int x = sw - pw - 6, y = 6;

        ctx.fill(x-2, y-2, x+pw+2, y+ph+2, 0xBB000000);

        int border = macroEnabled ? 0xFF00FF88 : 0xFFFF3333;
        ctx.fill(x-2, y-2,    x+pw+2, y-1,      border);
        ctx.fill(x-2, y+ph+1, x+pw+2, y+ph+2,   border);
        ctx.fill(x-2, y-2,    x-1,    y+ph+2,    border);
        ctx.fill(x+pw+1, y-2, x+pw+2, y+ph+2,   border);

        ctx.drawTextWithShadow(font, "⚡ COMBO MACRO", x+4, y+4, 0xFFFFAA00);

        String durum = macroEnabled ? "§a● AKTIF" : "§c● KAPALI";
        ctx.drawTextWithShadow(font, net.minecraft.text.Text.literal(durum), x+4, y+16, 0xFFFFFFFF);

        if (macroEnabled) {
            String adim = switch (step) {
                case 0, 1   -> "§6Anchor koyuyor...";
                case 2, 3   -> "§eGlowstone dolduruyor...";
                case 4, 5   -> "§cAnchor PATLIYOR!";
                case 6, 7   -> "§7Obsidyen koyuyor...";
                case 8      -> "§bKristal seciyor...";
                case 9, 10  -> "§b⚡ Kristal (" + kristalCount + "/" + KRISTAL_SAYISI + ")";
                default     -> "";
            };
            ctx.drawTextWithShadow(font, net.minecraft.text.Text.literal(adim), x+4, y+28, 0xFFFFFFFF);
        }

        ctx.drawTextWithShadow(font, net.minecraft.text.Text.literal("§7Anc:§f6 §7Glow:§f8 §7Patlat:§f9 §7Obs:§f4 §7Kris:§f2"), x+4, y+42, 0xFFAAAAAA);
        ctx.drawTextWithShadow(font, net.minecraft.text.Text.literal("§8[§76§8] Aç/Kapat"), x+4, y+56, 0xFFAAAAAA);
    }

    private void delay() {
        nextAction = System.currentTimeMillis() + MIN_MS + random.nextInt(MAX_MS - MIN_MS + 1);
    }

    private void msg(MinecraftClient client, String text) {
        if (client.player != null)
            client.player.sendMessage(net.minecraft.text.Text.literal(text), true);
    }
}
